public class DockerTest {
	public static void main(String[] args) {
		System.out.println("Hi Everyone Always Fighting~");
	}
}